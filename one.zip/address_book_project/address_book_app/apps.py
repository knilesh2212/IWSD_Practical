from django.apps import AppConfig


class AddressBookAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'address_book_app'
