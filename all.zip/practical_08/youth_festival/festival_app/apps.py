from django.apps import AppConfig


class FestivalAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'festival_app'
