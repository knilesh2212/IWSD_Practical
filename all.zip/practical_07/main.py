# main.py
import calculator

# Example usage of the calculator module

a = 10
b = 0

print(f"{a} + {b} = {calculator.add(a, b)}")
print(f"{a} - {b} = {calculator.subtract(a, b)}")
print(f"{a} * {b} = {calculator.multiply(a, b)}")
print(f"{a} / {b} = {calculator.divide(a, b)}")