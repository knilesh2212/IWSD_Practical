from django.apps import AppConfig


class EventRegistrationAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'event_registration_app'
