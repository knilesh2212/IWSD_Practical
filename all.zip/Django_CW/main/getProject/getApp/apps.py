from django.apps import AppConfig


class GetappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'getApp'
